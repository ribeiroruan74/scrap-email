# Web Scraping e Envio de E-mail

Este projeto realiza o scraping de citações da página [Quotes to Scrape](http://quotes.toscrape.com) e envia as citações por e-mail.

## Como rodar o projeto

### Pré-requisitos

- Node.js
- Conta de e-mail (Gmail ou outro)

### Instalação

1. Clone este repositório:

    ```bash
    git clone https://github.com/usuario/nome-do-repositorio.git
    ```

2. Instale as dependências:

    ```bash
    npm install
    ```

3. Crie um arquivo `.env` com suas credenciais de e-mail:

    ```plaintext
    EMAIL_USER=seu_email@gmail.com
    EMAIL_PASSWORD=sua_senha_de_app
    TO_EMAIL=destinatario@example.com
    ```

4. Execute o script:

    ```bash
    node index.js
    ```

Isso irá coletar as citações e enviar um e-mail com o conteúdo.

## Dependências

- `axios`: Para realizar requisições HTTP.
- `cheerio`: Para fazer o parsing do HTML.
- `nodemailer`: Para enviar o e-mail.
- `dotenv`: Para gerenciar variáveis de ambiente.
