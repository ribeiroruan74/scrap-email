const axios = require('axios');
const cheerio = require('cheerio');
const nodemailer = require('nodemailer');
const dotenv = require('dotenv');

// Carregar variáveis de ambiente do arquivo .env
dotenv.config();

// Função para fazer o scraping das citações
const scrapeQuotes = async () => {
  try {
    const { data } = await axios.get('http://quotes.toscrape.com/');
    const $ = cheerio.load(data);

    const quotes = [];
    $('span.text').each((index, element) => {
      const quote = $(element).text();
      quotes.push(quote);
    });

    return quotes;
  } catch (error) {
    console.error('Erro ao fazer scraping:', error);
    return [];
  }
};

// Função para enviar email
const sendEmail = async (subject, body, toEmail) => {
  const transporter = nodemailer.createTransport({
    service: 'gmail', // Pode ser outro serviço, como 'outlook', 'yahoo', etc.
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASSWORD
    }
  });

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: toEmail,
    subject: subject,
    text: body
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('E-mail enviado com sucesso!');
  } catch (error) {
    console.error('Erro ao enviar o e-mail:', error);
  }
};

// Função principal
const main = async () => {
  // Fazer o scraping das citações
  const quotes = await scrapeQuotes();

  if (quotes.length === 0) {
    console.log('Nenhuma citação encontrada.');
    return;
  }

  // Formatar as citações para enviar por e-mail
  const subject = 'Citações do dia';
  const body = quotes.join('\n');

  // Enviar o email
  sendEmail(subject, body, process.env.TO_EMAIL);
};

main();
